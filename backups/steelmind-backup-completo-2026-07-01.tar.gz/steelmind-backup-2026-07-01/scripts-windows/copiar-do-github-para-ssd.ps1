# SteelMind — Baixar do GitHub + clonar dados Gestio para o SSD
# Use se voce recebeu apenas o backup parcial ou quer versao atualizada do repo

$ErrorActionPreference = "Stop"
$Destino = "\\Paulo\projeto api\steelmind"
$Repo = "https://github.com/PauloSergiodaRocha32/steelmind.git"
$Branch = "cursor/gestio-import-3dc9"

if (-not (Test-Path "\\Paulo\projeto api")) {
    Write-Host "ERRO: \\Paulo\projeto api nao acessivel." -ForegroundColor Red
    exit 1
}

New-Item -ItemType Directory -Force -Path $Destino | Out-Null

if (Get-Command git -ErrorAction SilentlyContinue) {
    if (Test-Path "$Destino\.git") {
        Set-Location $Destino
        git fetch origin
        git checkout $Branch
        git pull origin $Branch
    } else {
        git clone -b $Branch $Repo $Destino
    }
    Set-Location $Destino
    npm install
    Write-Host "Projeto clonado em $Destino" -ForegroundColor Green
    Write-Host "Configure .env com GESTIO_EMAIL e GESTIO_PASSWORD, depois: npm run gestio:sync"
} else {
    Write-Host "Git nao instalado. Baixe o ZIP em: https://github.com/PauloSergiodaRocha32/steelmind/archive/refs/heads/cursor/gestio-import-3dc9.zip"
}
