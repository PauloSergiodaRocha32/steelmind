# SteelMind — Copiar backup para SSD externo
# Destino: \\Paulo\projeto api
# Execute no PowerShell como Administrador (se necessário)

$ErrorActionPreference = "Stop"

$Destino = "\\Paulo\projeto api\steelmind-backup-2026-07-01"
$Origem = $PSScriptRoot + "\.."

Write-Host "Destino: $Destino" -ForegroundColor Cyan

if (-not (Test-Path "\\Paulo\projeto api")) {
    Write-Host "ERRO: SSD/rede \\Paulo\projeto api nao encontrado." -ForegroundColor Red
    Write-Host "Verifique se o SSD esta conectado e compartilhado como 'Paulo'."
    exit 1
}

New-Item -ItemType Directory -Force -Path $Destino | Out-Null

Write-Host "Copiando backup..." -ForegroundColor Yellow
Copy-Item -Path "$Origem\*" -Destination $Destino -Recurse -Force

Write-Host "Backup concluido em: $Destino" -ForegroundColor Green
Get-ChildItem $Destino -Recurse | Measure-Object -Property Length -Sum |
    ForEach-Object { Write-Host ("Total: {0:N2} MB" -f ($_.Sum / 1MB)) }
